# Frontend — Vue 3 + Pinia + Vue Router

## Requisitos
- Node.js 18+

## Instalação
cd frontend
npm install
npm run dev

Abra http://localhost:5173

## Variáveis de ambiente
Crie/edite `.env`:
```
VITE_API_URL=http://localhost:3000/api
```
