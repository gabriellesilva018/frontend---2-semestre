<template>
  <section>
    <p>Bem-vinda! Use o menu acima para acessar a lista de usuários.</p>
  </section>
</template>
